function validateForm() {
    let isValid = true;

    // Get form fields
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('password').value.trim(); // Changed from 'password' to 'message'

    // Get error message spans
    const usernameError = document.getElementById('usernameError');
    const emailError = document.getElementById('emailError');
    const messageError = document.getElementById('passwordError'); // Changed from 'passwordError' to 'messageError'

    // Clear previous error messages
    usernameError.textContent = '';
    emailError.textContent = '';
    messageError.textContent = '';

    // Username validation
    if (username === '') {
        usernameError.textContent = 'Username is required.';
        isValid = false;
    }

    // Email validation
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (email === '') {
        emailError.textContent = 'Email is required.';
        isValid = false;
    } else if (!email.match(emailPattern)) {
        emailError.textContent = 'Enter a valid email address.';
        isValid = false;
    }

    // Message validation
    if (message === '') {
        messageError.textContent = 'Message is required.';
        isValid = false;
    }

    // If the form is valid, show success alert
    if (isValid) {
        alert('Your message has been sent successfully!');
    }

    // Return validation result
    return isValid;
}
