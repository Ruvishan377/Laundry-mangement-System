function exploreServices() {
    alert("Explore our services including washing, ironing, dry cleaning, and more!");
}

function performSearch() {
    var query = document.getElementById("search").value;
    if (query) {
        alert("Searching for: " + query);
    } else {
        alert("Please enter a search term.");
    }
}
const images = ['image1.jpg', 'image2.jpg', 'image3.jpg']; 
let currentIndex = 0;

function changeImage() {
    const sliderImg = document.getElementById('slider-img');
    currentIndex = (currentIndex + 1) % images.length; // Cycle through images
    sliderImg.src = images[currentIndex];
}

// Change image every 3 seconds
setInterval(changeImage, 3000);
